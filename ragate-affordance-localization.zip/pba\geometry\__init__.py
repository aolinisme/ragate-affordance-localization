"""Geometry probing orchestration helpers."""

